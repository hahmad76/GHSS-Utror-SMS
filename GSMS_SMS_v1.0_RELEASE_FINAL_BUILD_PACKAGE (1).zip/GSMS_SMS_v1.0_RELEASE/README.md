# GSMS SMS v1.0 — GHSS Utror Swat

Release candidate source package for the approved SMS-only system.

## Target release artifacts
- `GSMS_SMS_v1.0.apk` — Android SMS gateway using the phone's SIM 1.
- `GSMS_SMS_v1.0.exe` — Windows PC management application.

## v1.0 scope
- Student/parent and staff contacts
- CSV/XLSX import
- Individual and bulk SMS preparation
- Queue with pause/resume
- Controlled sending rate and safety limits
- Android phone SIM 1 as SMS transmitter
- PC ↔ Android over the same local Wi-Fi network
- Principal login and local data storage
- No Exam, Result, Fee modules

## Important build note
This package is a release-candidate source package. The included GitHub Actions workflow is configured to build the Windows EXE and Android release APK on hosted runners. The Android artifact produced by this workflow is intentionally **unsigned** until a release signing key is configured and protected separately.

The final v1.0 distribution APK should be signed with a release keystore that is kept private and backed up securely. Do not commit a keystore or passwords to the repository.

## Build with GitHub Actions
1. Upload this folder to a GitHub repository.
2. Open **Actions → Build GSMS SMS v1.0**.
3. Run the workflow manually or push a tag such as `v1.0.0`.
4. Download:
   - `GSMS_SMS_v1.0-unsigned` for the Android release APK
   - `GSMS_SMS_v1.0.exe` for the Windows application
5. For the final public/private school release, sign the APK with the school's protected release keystore before installation.

The user of the finished software does not need Flutter, Android Studio, Java, or Python installed.
