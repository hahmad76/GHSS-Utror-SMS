# GSMS SMS v1.0 Release Audit

Checked on 30 July 2026.

## Source package checks
- Windows Python source: syntax check passed.
- Android project structure: present.
- Android applicationId: `com.ghssutror.gsms`.
- Android target SDK: 35.
- Windows safety limits present: 150/15 min, 250/hour, 750/24 hours.
- Excel/CSV import present.
- PC-to-phone token authentication present.
- SIM-slot-0 selection logic present.

## Blocking item found and corrected
The original workflow called `./gradlew`, but the uploaded package did not contain a Gradle wrapper (`gradlew` / `gradle-wrapper.jar`). The workflow has therefore been changed to install Gradle 8.7 with the official Gradle setup action and invoke `gradle assembleRelease`.

## Release-signing status
The Android build is intentionally produced as an unsigned release APK by the supplied workflow. A protected release keystore must be configured before the APK is treated as the final distributable v1.0 build.

## Not physically verified in this environment
- Android APK installation on a physical phone.
- Telenor SIM 1 SMS transmission.
- PC/Android Wi-Fi communication on a real network.
- Windows EXE execution on Windows 10/11.
- Carrier acceptance and delivery of live SMS.

These require the actual APK/EXE and physical devices.
