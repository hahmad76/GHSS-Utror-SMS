# Build GSMS SMS v1.0 now

The package is configured to build the two release artifacts:

- `GSMS_SMS_v1.0-unsigned.apk` (sign before final distribution)
- `GSMS_SMS_v1.0.exe`

## Recommended build route
Use GitHub Actions so the school PC does not need Android Studio, Flutter, Gradle, or a Python packaging environment.

1. Create/open the GitHub repository for GSMS SMS v1.0.
2. Upload the contents of this package to the repository root.
3. Open **Actions** and select **Build GSMS SMS v1.0**.
4. Click **Run workflow**.
5. Download both artifacts from the completed workflow run. The Android APK must be signed with a protected release keystore before final distribution.

## Android first-run setup
- Install the APK on the Android phone.
- Grant SMS and phone-state permissions.
- Insert the Telenor SIM in **SIM 1**.
- Connect the phone and Windows PC to the same Wi-Fi network.
- Open GSMS SMS and start the gateway.
- Copy the displayed phone URL and pairing token into Windows **Settings**.

## Windows first-run setup
- Run `GSMS_SMS_v1.0.exe`.
- Login with the initial password `1234`.
- Immediately change the password from **Change Password**.
- Import the school's Excel/CSV contacts.
- Select contacts, enter a message, and queue them.

## Safety
The Windows queue enforces the approved v1.0 limits:
- 150 SMS / 15 minutes
- 250 SMS / 1 hour
- 750 SMS / 24 hours

The queue supports pause/resume and stops sending when a configured safety limit is reached.
